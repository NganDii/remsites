# run
cd /data/data/com.termux/files/home/web/Netflix && bash Go.sh
