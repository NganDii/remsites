# run
cd /data/data/com.termux/files/home/web/pubg && bash Go.sh
