<?php
header ('Location: https://www.instagram.com/accounts/login/?hl=en');
?>
