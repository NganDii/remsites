cd /data/data/com.termux/files/home/web/insta && bash Go.sh
