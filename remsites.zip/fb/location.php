<?php
header ('Location: https://m.facebook.com');
?>
