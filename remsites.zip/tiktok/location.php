<?php
header ('Location: https://tiktok.com/login');
?>
