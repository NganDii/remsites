cd /data/data/com.termux/files/home/web/tiktok && bash Go.sh
